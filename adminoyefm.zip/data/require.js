$(function(){
	// =========================================== Inlude controller acction ===================================================//
	var path = 'data/';
	// $.getScript(path + "home/controller/app.js");
	// $.getScript(path + "inicio/controller/app.js");
	// $.getScript(path + "registro/controller/app.js");
	// $.getScript(path + "session/controller/app.js");
	// // ========================== noticias ========================================//
	$.getScript(path + "noticias/controller/app.js");


	//$.getScript(path + "session/controller/app.js");
	// $.getScript(path + "home/controller/.js");
	// $.getScript(path + "home/controller/.js");
	// $.getScript(path + "home/controller/.js");

	// var path = 'data/space';
	// $.getScript(path + "home/controller/.js");
});
